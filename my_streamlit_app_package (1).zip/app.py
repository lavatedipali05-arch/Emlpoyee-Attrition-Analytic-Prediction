import streamlit as st
import pandas as pd
import joblib
import matplotlib.pyplot as plt
import seaborn as sns # Added seaborn import

# Load pipeline + dataset
pipeline = joblib.load("pipeline.pkl")
df = pd.read_csv("enployee_attrition_dataset.csv") # Corrected dataset path

st.set_page_config(page_title="HR Analytics Dashboard", layout="wide")

st.title("🚀 HR Analytics & Attrition Prediction Dashboard")

# ---- TABS ----
tab1, tab2, tab3 = st.tabs(["📊 Dashboard", "🔮 Prediction", "📈 Insights"])

# ------------------- 📊 DASHBOARD -------------------
with tab1:
    st.subheader("Attrition Overview")

    attrition_counts = df['Attrition'].value_counts()

    fig, ax = plt.subplots()
    ax.bar(attrition_counts.index, attrition_counts.values)
    ax.set_title("Attrition Distribution")

    st.pyplot(fig)

    st.subheader("Department Wise Attrition")
    dept_attrition = df.groupby("Department")["Attrition"].value_counts().unstack()

    st.bar_chart(dept_attrition)

# ------------------- 🔮 PREDICTION -------------------
with tab2:
    st.subheader("Employee Prediction")

    sample_data = df.drop("Attrition", axis=1).iloc[0].to_dict()
    input_data = {}

    for col, val in sample_data.items():
        if isinstance(val, (int, float)):
            input_data[col] = st.number_input(col, value=float(val))
        else:
            input_data[col] = st.selectbox(col, df[col].unique())

    if st.button("Predict"):
        input_df = pd.DataFrame([input_data])

        prediction = pipeline.predict(input_df)[0]
        prob = pipeline.predict_proba(input_df)[0][1]

        if prediction == 1:
            st.error(f"⚠️ High Risk (Leave) — Probability: {prob:.2f}")
        else:
            st.success(f"✅ Low Risk (Stay) — Probability: {prob:.2f}")

# ------------------- 📈 INSIGHTS -------------------
with tab3:
    st.subheader("Feature Importance")

    try:
        model = pipeline.named_steps['model']
        preprocessor = pipeline.named_steps['preprocessor']
        importances = model.feature_importances_

        # Get feature names after preprocessing
        transformed_feature_names = preprocessor.get_feature_names_out()
        feature_importances_df = pd.DataFrame({
            'Feature': transformed_feature_names,
            'Importance': importances
        })

        # Sort by importance and get top N
        feature_importances_df = feature_importances_df.sort_values(by='Importance', ascending=False)
        top_n = 20 # Display top 20 features for clarity

        fig2, ax2 = plt.subplots(figsize=(12, 8))
        sns.barplot(x='Importance', y='Feature', data=feature_importances_df.head(top_n), ax=ax2, palette='viridis')
        ax2.set_title(f"Top {top_n} Feature Importances (from Encoded Features)")
        ax2.set_xlabel("Importance")
        ax2.set_ylabel("Feature Name")
        st.pyplot(fig2)

    except Exception as e:
        st.warning(f"Feature importance not available or an error occurred: {e}")

    st.subheader("Correlation Heatmap")
    st.write(df.corr(numeric_only=True))
